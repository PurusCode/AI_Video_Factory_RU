$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$Root = (Resolve-Path -LiteralPath $PSScriptRoot).Path
$CliPath = Join-Path $Root 'src\video_farm\cli.py'
$DiscoveryPath = Join-Path $Root 'src\video_farm\discovery.py'
$PythonVenv = Join-Path $Root '.venv\Scripts\python.exe'
$PayloadRoot = Join-Path $Root 'stage3'

if (-not (Test-Path -LiteralPath $CliPath -PathType Leaf) -or -not (Test-Path -LiteralPath $DiscoveryPath -PathType Leaf)) {
    throw "Не найден корень video-farm. Распакуйте архив непосредственно в корень проекта, где находятся src\video_farm\cli.py и discovery.py."
}
if (-not (Test-Path -LiteralPath (Join-Path $PayloadRoot 'src\video_farm\discovery_analysis.py') -PathType Leaf)) {
    throw 'В архиве отсутствуют файлы Stage 3. Повторно скачайте полный установочный архив.'
}
if (-not (Test-Path -LiteralPath $PythonVenv -PathType Leaf)) {
    $PythonCommand = Get-Command python -ErrorAction SilentlyContinue
    if ($null -eq $PythonCommand) { throw 'Не найден Python. Ожидался .venv\Scripts\python.exe или python в PATH.' }
    $PythonExe = $PythonCommand.Source
} else {
    $PythonExe = $PythonVenv
}

$BackupRoot = Join-Path $Root ('backups\discovery-stage3-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$Changes = [System.Collections.Generic.List[object]]::new()
$Utf8NoBom = [System.Text.UTF8Encoding]::new($false)

function Save-BackupAndRegister([string]$TargetPath) {
    $HadOriginal = Test-Path -LiteralPath $TargetPath -PathType Leaf
    $BackupPath = $null
    if ($HadOriginal) {
        $Relative = $TargetPath.Substring($Root.Length).TrimStart([char[]]@(92,47))
        $BackupPath = Join-Path $BackupRoot $Relative
        $BackupDirectory = Split-Path -Parent $BackupPath
        New-Item -ItemType Directory -Path $BackupDirectory -Force | Out-Null
        Copy-Item -LiteralPath $TargetPath -Destination $BackupPath -Force
    }
    $Changes.Add([pscustomobject]@{ Target = $TargetPath; HadOriginal = $HadOriginal; Backup = $BackupPath })
}

function Invoke-PythonChecked([string[]]$Arguments, [string]$Label) {
    & $PythonExe @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$Label завершилась с кодом $LASTEXITCODE." }
}

try {
    # Patch the current CLI only at known Stage 2 anchors. Unknown source versions fail safely.
    $CliText = [System.IO.File]::ReadAllText($CliPath)
    $CliText = $CliText.Replace("`r`n", "`n").Replace("`r", "`n")
    $ImportLine = 'from .discovery_analysis import analyze_discovery'
    if (-not $CliText.Contains($ImportLine)) {
        $ImportAnchor = @'
from .discovery import (discover_youtube, purge_expired_discovery_output,
                        DEFAULT_MAX_RESULTS, DEFAULT_MAX_PAGES, DEFAULT_SEARCH_CALL_BUDGET)
'@
        $ImportAnchor = $ImportAnchor.Trim([char[]]@(10,13))
        if (-not $CliText.Contains($ImportAnchor)) { throw 'Не найден ожидаемый блок импортов Stage 2 в cli.py. Файлы не установлены; проверьте версию проекта.' }
        $CliText = $CliText.Replace($ImportAnchor, $ImportAnchor + "`n" + $ImportLine)
    }

    if (-not $CliText.Contains('def cmd_discover_analyze(')) {
        $FunctionAnchor = 'def cmd_discover_cleanup(args: argparse.Namespace) -> int:'
        if (-not $CliText.Contains($FunctionAnchor)) { throw 'Не найдено место для добавления обработчика discover-analyze в cli.py.' }
        $FunctionText = @'
def cmd_discover_analyze(args: argparse.Namespace) -> int:
    source = _path(args.input)
    out = _path(args.out)
    report = analyze_discovery(source, out, limit=args.limit)
    print(f"Редакторские подборки: {out / 'topics.json'} и {out / 'topics.md'}")
    print(f"Обработано уникальных видео: {report['candidate_count']}")
    print("Автоматическая семантическая классификация и трендовые метрики не выполняются.")
    return 0


'@
        $CliText = $CliText.Replace($FunctionAnchor, $FunctionText.Trim([char[]]@(10,13)) + "`n`n" + $FunctionAnchor)
    }

    if (-not $CliText.Contains('sub.add_parser("discover-analyze"')) {
        $ParserAnchor = '    disc.set_defaults(func=cmd_discover)'
        if (-not $CliText.Contains($ParserAnchor)) { throw 'Не найдено место регистрации команды discover в build_parser().' }
        $ParserText = @'
    da = sub.add_parser("discover-analyze", help="Создать редакторские подборки из сохранённого discovery.json")
    da.add_argument("--input", default="output/discovery/discovery.json", help="Исходный discovery.json версии 2.0")
    da.add_argument("--out", default="output/discovery", help="Каталог для topics.json и topics.md")
    da.add_argument("--limit", type=int, default=20, help="Максимум видео в каждой подборке (1–100)")
    da.set_defaults(func=cmd_discover_analyze)
'@
        $CliText = $CliText.Replace($ParserAnchor, $ParserAnchor + "`n" + $ParserText.Trim([char[]]@(10,13)))
    }

    # Extend the existing 30-day cleanup so Stage 3 copies are also removed at expiry.
    $DiscoveryText = [System.IO.File]::ReadAllText($DiscoveryPath)
    $DiscoveryText = $DiscoveryText.Replace("`r`n", "`n").Replace("`r", "`n")
    $CleanupAnchor = @'
    json_path.unlink(missing_ok=True)
    (out_dir / "discovery.md").unlink(missing_ok=True)
    return True
'@
    $CleanupAnchor = $CleanupAnchor.Trim([char[]]@(10,13))
    $CleanupReplacement = @'
    json_path.unlink(missing_ok=True)
    (out_dir / "discovery.md").unlink(missing_ok=True)
    # Stage 3 reports contain copied YouTube API fields and share the same deadline.
    (out_dir / "topics.json").unlink(missing_ok=True)
    (out_dir / "topics.md").unlink(missing_ok=True)
    return True
'@
    $CleanupReplacement = $CleanupReplacement.Trim([char[]]@(10,13))
    if ($DiscoveryText.Contains($CleanupAnchor)) {
        $DiscoveryText = $DiscoveryText.Replace($CleanupAnchor, $CleanupReplacement)
    } elseif (-not $DiscoveryText.Contains('(out_dir / "topics.json").unlink(missing_ok=True)')) {
        throw 'Не найден ожидаемый блок 30-дневной очистки в discovery.py. Версия проекта не совпадает; файлы не установлены.'
    }

    Save-BackupAndRegister $CliPath
    [System.IO.File]::WriteAllText($CliPath, $CliText, $Utf8NoBom)
    Save-BackupAndRegister $DiscoveryPath
    [System.IO.File]::WriteAllText($DiscoveryPath, $DiscoveryText, $Utf8NoBom)

    $FilesToInstall = @(
        @{ Source = (Join-Path $PayloadRoot 'src\video_farm\discovery_analysis.py'); Target = (Join-Path $Root 'src\video_farm\discovery_analysis.py') },
        @{ Source = (Join-Path $PayloadRoot 'tests\test_discovery_analysis.py'); Target = (Join-Path $Root 'tests\test_discovery_analysis.py') },
        @{ Source = (Join-Path $PayloadRoot 'docs\TREND_DISCOVERY_STAGE3.md'); Target = (Join-Path $Root 'docs\TREND_DISCOVERY_STAGE3.md') }
    )
    foreach ($File in $FilesToInstall) {
        $Parent = Split-Path -Parent $File.Target
        New-Item -ItemType Directory -Path $Parent -Force | Out-Null
        Save-BackupAndRegister $File.Target
        Copy-Item -LiteralPath $File.Source -Destination $File.Target -Force
    }

    $env:PYTHONPATH = (Join-Path $Root 'src') + [System.IO.Path]::PathSeparator + $env:PYTHONPATH
    Invoke-PythonChecked @('-m','py_compile', (Join-Path $Root 'src\video_farm\discovery_analysis.py'), $CliPath, $DiscoveryPath) 'Проверка синтаксиса'
    Invoke-PythonChecked @('-m','pytest','tests\test_discovery_analysis.py','-q') 'Тесты Stage 3'
    Invoke-PythonChecked @('-m','video_farm.cli','discover-analyze','--help') 'Проверка CLI'

    Write-Host ''
    Write-Host 'Stage 3 установлен успешно.' -ForegroundColor Green
    Write-Host 'Исходный discovery.json не изменялся. YouTube API не вызывался.'
    Write-Host "Резервные копии: $BackupRoot"
    Write-Host 'Запуск обработки:'
    Write-Host '.\.venv\Scripts\python.exe -m video_farm.cli discover-analyze'
}
catch {
    Write-Host ''
    Write-Host ('Установка не завершена: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Выполняю откат изменений...'
    for ($i = $Changes.Count - 1; $i -ge 0; $i--) {
        $Change = $Changes[$i]
        if ($Change.HadOriginal -and $Change.Backup -and (Test-Path -LiteralPath $Change.Backup)) {
            Copy-Item -LiteralPath $Change.Backup -Destination $Change.Target -Force
        } elseif (Test-Path -LiteralPath $Change.Target) {
            Remove-Item -LiteralPath $Change.Target -Force
        }
    }
    Write-Host 'Откат выполнен. Исходные файлы восстановлены.' -ForegroundColor Yellow
    throw
}
