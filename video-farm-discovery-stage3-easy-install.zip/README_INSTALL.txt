DISCOVERY STAGE 3 — ПРОСТАЯ УСТАНОВКА

1. Распакуйте архив непосредственно в корень локальной папки video-farm.
   Это папка, в которой находятся README.md, pyproject.toml, src и .venv.

2. Откройте PowerShell в этой папке и выполните две команды:

   Set-ExecutionPolicy -Scope Process Bypass
   .\install_stage3.ps1

Больше ничего вручную менять не нужно.

Установщик сам:
- добавляет новую команду discover-analyze в CLI;
- устанавливает модуль, тесты и документацию;
- расширяет существующую 30-дневную очистку, чтобы она удаляла и topics.json/topics.md;
- сохраняет резервные копии изменяемых файлов в backups\discovery-stage3-ДАТА-ВРЕМЯ;
- проверяет синтаксис, запускает тесты и проверяет справку CLI;
- при ошибке автоматически восстанавливает исходные файлы.

После успешной установки запустите:

   .\.venv\Scripts\python.exe -m video_farm.cli discover-analyze

В output\discovery появятся topics.json и topics.md.
Исходные discovery.json и discovery.md не перезаписываются. YouTube API повторно не вызывается.

Установщик не изменяет .env, модели, виртуальное окружение, исходную выборку Discovery и существующие видео.
