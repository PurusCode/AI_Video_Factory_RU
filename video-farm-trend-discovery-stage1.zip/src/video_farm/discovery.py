from __future__ import annotations

"""YouTube candidate discovery using raw Data API fields only.

This module deliberately does not calculate view velocity, trend scores,
channel-relative ratios, topic clusters, or other derived metrics. Those
features must remain disabled unless the API client has obtained the
necessary YouTube approval for additional derived metrics.
"""

import datetime as dt
import logging
from pathlib import Path
from typing import Any

import requests

from .common import read_json, write_json
from .config import Settings

log = logging.getLogger(__name__)
API = "https://www.googleapis.com/youtube/v3"

# One broad query keeps the first implementation within a small, predictable
# search.list budget. The OR operator is documented by YouTube for search.list.
DEFAULT_QUERY = (
    "нейросети|искусственный интеллект|ChatGPT|Gemini|Claude|DeepSeek|"
    "локальные модели ИИ|ИИ инструменты"
)
WINDOWS_DAYS = (1, 3, 7)
ORDERS = ("viewCount", "date", "relevance")


def _get(path: str, params: dict[str, Any], api_key: str) -> dict[str, Any]:
    response = requests.get(
        f"{API}/{path}",
        params={**params, "key": api_key},
        timeout=35,
    )
    if response.status_code >= 400:
        # Do not include request URL: it contains the API key.
        raise RuntimeError(
            f"YouTube API {response.status_code} for {path}: {response.text[:700]}"
        )
    payload = response.json()
    if not isinstance(payload, dict):
        raise RuntimeError(f"YouTube API returned an unexpected response for {path}.")
    return payload


def _rfc3339(value: dt.datetime) -> str:
    if value.tzinfo is None:
        raise ValueError("now must be timezone-aware")
    return value.astimezone(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _fetch_video_details(
    video_ids: list[str], api_key: str
) -> dict[str, dict[str, Any]]:
    """Fetch raw video fields for IDs returned by one search.list response."""
    if not video_ids:
        return {}
    response = _get(
        "videos",
        {
            "part": "snippet,statistics,contentDetails",
            "id": ",".join(video_ids[:50]),
            "maxResults": min(50, len(video_ids)),
        },
        api_key,
    )
    return {
        str(item.get("id")): item
        for item in response.get("items", [])
        if isinstance(item, dict) and item.get("id")
    }


def _raw_video_record(
    search_item: dict[str, Any], detail: dict[str, Any] | None
) -> dict[str, Any] | None:
    resource_id = search_item.get("id", {})
    video_id = resource_id.get("videoId") if isinstance(resource_id, dict) else None
    if not video_id:
        return None

    search_snippet = search_item.get("snippet", {})
    detail = detail or {}
    snippet = detail.get("snippet", {}) or search_snippet
    statistics = detail.get("statistics", {})
    content_details = detail.get("contentDetails", {})

    # These are raw API values. No normalized/estimated statistics are added.
    return {
        "video_id": str(video_id),
        "url": f"https://www.youtube.com/watch?v={video_id}",
        "title": snippet.get("title") or search_snippet.get("title", ""),
        "channel_id": snippet.get("channelId") or search_snippet.get("channelId", ""),
        "channel_title": snippet.get("channelTitle") or search_snippet.get("channelTitle", ""),
        "published_at": snippet.get("publishedAt") or search_snippet.get("publishedAt", ""),
        "view_count": int(statistics["viewCount"]) if "viewCount" in statistics else None,
        "like_count": int(statistics["likeCount"]) if "likeCount" in statistics else None,
        "comment_count": int(statistics["commentCount"]) if "commentCount" in statistics else None,
        "duration": content_details.get("duration"),
        "category_id": snippet.get("categoryId"),
    }


def _format_count(value: int | None) -> str:
    return "н/д" if value is None else f"{value:,}".replace(",", " ")


def _make_markdown(report: dict[str, Any]) -> str:
    lines = [
        "# Ежедневный поиск популярных видео — YouTube",
        "",
        f"- Сформировано (UTC): {report['generated_at_utc']}",
        f"- Регион доступности видео: `{report['region_code']}`",
        f"- Приоритет языка результатов: `{report['relevance_language']}`",
        f"- Поисковый запрос: `{report['query']}`",
        "- Источник: YouTube Data API v3",
        "",
        "> Это списки отдельных результатов API, а не исчерпывающий рейтинг всего YouTube.",
        "> Порядок внутри каждой выборки соответствует указанной сортировке YouTube API.",
        "> `viewCount`, `likeCount` и `commentCount` — исходные значения API; скорость роста и трендовый балл не рассчитываются.",
        "",
    ]

    for window in report["windows"]:
        days = window["window_days"]
        lines += [f"## Опубликовано за последние {days} дн.", ""]
        for key, heading in (("viewCount", "Наибольшее число просмотров (сортировка API: viewCount)"),
                             ("date", "Самые новые публикации (сортировка API: date)"),
                             ("relevance", "Наиболее релевантные поисковому запросу (сортировка API: relevance)")):
            result_set = window["sets"][key]
            lines += [f"### {heading}", ""]
            lines += ["| Просмотры | Лайки | Комментарии | Дата публикации | Длительность | Канал | Видео |", "|---:|---:|---:|---|---|---|---|"]
            for video in result_set["videos"]:
                title = str(video.get("title", "")).replace("|", "\\|").replace("\n", " ")
                channel = str(video.get("channel_title", "")).replace("|", "\\|").replace("\n", " ")
                url = video.get("url", "")
                lines.append(
                    f"| {_format_count(video.get('view_count'))} "
                    f"| {_format_count(video.get('like_count'))} "
                    f"| {_format_count(video.get('comment_count'))} "
                    f"| {video.get('published_at', '')} "
                    f"| {video.get('duration') or 'н/д'} "
                    f"| {channel} | [{title}]({url}) |"
                )
            if not result_set["videos"]:
                lines.append("| — | — | — | — | — | — | Нет результатов |")
            lines.append("")

    lines += [
        "## Ограничения и правила интерпретации",
        "",
        "- Сортировка, отличная от `relevance`, совместно с фильтром даты может возвращать неполную выборку; три сортировки показываются отдельно, но ни одна не гарантирует полный охват.",
        "- `relevanceLanguage=ru` задаёт языковой приоритет, но сам по себе не гарантирует, что все результаты будут русскоязычными.",
        "- `regionCode` ограничивает доступность видео в регионе, а не страну проживания автора.",
        "- Это поиск кандидатов для ручного выбора. Автоматическое объединение роликов в темы, сравнительные баллы и скорость прироста просмотров в этой версии отключены.",
        "- Сохранённые данные YouTube API следует обновить или удалить не позднее чем через 30 календарных дней. Отчёт перезаписывается при следующем запуске.",
        "",
    ]
    return "\n".join(lines)



def purge_expired_discovery_output(
    out_dir: Path, *, now: dt.datetime | None = None
) -> bool:
    """Delete this module's raw API report after its 30-day refresh deadline.

    The function is intentionally scoped to discovery.json and discovery.md
    inside the selected output directory. It never traverses or deletes other
    project files.
    """
    json_path = out_dir / "discovery.json"
    if not json_path.is_file():
        return False
    try:
        report = read_json(json_path)
        deadline = report.get("refresh_or_delete_by_utc")
        if not deadline:
            return False
        deadline_dt = dt.datetime.fromisoformat(str(deadline).replace("Z", "+00:00"))
        current = now or dt.datetime.now(dt.timezone.utc)
        if current.tzinfo is None:
            raise ValueError("now must be timezone-aware")
        expired = current.astimezone(dt.timezone.utc) >= deadline_dt.astimezone(dt.timezone.utc)
    except (OSError, ValueError, TypeError):
        # Unknown/corrupt reports are preserved for manual inspection.
        return False
    if not expired:
        return False
    json_path.unlink(missing_ok=True)
    (out_dir / "discovery.md").unlink(missing_ok=True)
    return True

def discover_youtube(
    settings: Settings,
    out_dir: Path,
    *,
    query: str = DEFAULT_QUERY,
    region: str = "RU",
    language: str = "ru",
    max_results: int = 50,
    now: dt.datetime | None = None,
) -> dict[str, Any]:
    """Find recent video candidates in three time windows.

    It makes three independent search.list requests per window: raw API view count,
    publication date, and relevance. Each result set remains separate. Search result sets
    are kept separate; no cross-window de-duplication, aggregation, topic
    clustering, velocity, or custom score is performed.
    """
    if not settings.youtube_api_key:
        raise RuntimeError(
            "Не задан YOUTUBE_API_KEY. Поиск использует официальный YouTube Data API v3; скрейпинг не выполняется."
        )
    query = str(query or "").strip()
    if not query:
        raise ValueError("Поисковый запрос не должен быть пустым")
    if not 1 <= int(max_results) <= 50:
        raise ValueError("max_results должен быть в диапазоне от 1 до 50")
    region = str(region or "RU").upper().strip()
    language = str(language or "ru").strip()
    now = now or dt.datetime.now(dt.timezone.utc)
    if now.tzinfo is None:
        raise ValueError("now must be timezone-aware")

    generated_at = _rfc3339(now)
    expires_at = _rfc3339(now + dt.timedelta(days=30))
    windows: list[dict[str, Any]] = []
    search_calls = 0
    video_detail_calls = 0

    for days in WINDOWS_DAYS:
        published_after = _rfc3339(now - dt.timedelta(days=days))
        sets: dict[str, Any] = {}
        for order in ORDERS:
            search_response = _get(
                "search",
                {
                    "part": "snippet",
                    "type": "video",
                    "q": query,
                    "maxResults": int(max_results),
                    "order": order,
                    "publishedAfter": published_after,
                    "regionCode": region,
                    "relevanceLanguage": language,
                    "safeSearch": "moderate",
                },
                settings.youtube_api_key,
            )
            search_calls += 1
            search_items = [
                item for item in search_response.get("items", [])
                if isinstance(item, dict)
            ]
            video_ids = [
                item.get("id", {}).get("videoId")
                for item in search_items
                if isinstance(item.get("id"), dict) and item["id"].get("videoId")
            ]
            details = _fetch_video_details(video_ids, settings.youtube_api_key)
            if video_ids:
                video_detail_calls += 1
            videos = [
                record
                for item in search_items
                if (record := _raw_video_record(
                    item,
                    details.get(str(item.get("id", {}).get("videoId")))
                    if isinstance(item.get("id"), dict) else None,
                )) is not None
            ]
            sets[order] = {
                "order": order,
                "published_after": published_after,
                "api_total_results": search_response.get("pageInfo", {}).get("totalResults"),
                "videos": videos,
            }
        windows.append({"window_days": days, "sets": sets})

    report: dict[str, Any] = {
        "schema_version": "1.0",
        "source": "YouTube Data API v3",
        "generated_at_utc": generated_at,
        "refresh_or_delete_by_utc": expires_at,
        "region_code": region,
        "relevance_language": language,
        "query": query,
        "windows": windows,
        "quota_usage": {
            "search_list_calls": search_calls,
            "search_list_quota_units": search_calls,
            "videos_list_calls": video_detail_calls,
            "videos_list_quota_units": video_detail_calls,
            "note": "Search.list uses the separate Search Queries quota bucket; videos.list uses the standard quota bucket.",
        },
        "notes": [
            "Все отображаемые счётчики — исходные поля YouTube Data API; собственные рейтинги не вычисляются.",
            "Порядок результатов сохраняется таким, каким его вернул YouTube API.",
            "Сортировка viewCount с publishedAfter может возвращать неполную выборку; order=date выполняется отдельным запросом.",
            "Поиск не загружает и не сохраняет чужие аудио- или видеоматериалы.",
            "Данные Non-Authorized Data следует обновить или удалить в пределах 30 календарных дней.",
        ],
    }

    out_dir.mkdir(parents=True, exist_ok=True)
    write_json(out_dir / "discovery.json", report)
    (out_dir / "discovery.md").write_text(_make_markdown(report), encoding="utf-8")
    return report
