import datetime as dt
import json

import pytest

from video_farm.config import Settings
from video_farm.discovery import DEFAULT_QUERY, discover_youtube, purge_expired_discovery_output


def _settings(api_key="test-key"):
    return Settings(
        root=__import__('pathlib').Path('.'),
        data_dir=__import__('pathlib').Path('data'),
        output_dir=__import__('pathlib').Path('output'),
        cache_dir=__import__('pathlib').Path('cache'),
        broll_dir=__import__('pathlib').Path('broll'),
        images_dir=__import__('pathlib').Path('images'),
        audio_dir=__import__('pathlib').Path('audio'),
        ffmpeg='ffmpeg', ffprobe='ffprobe', width=1920, height=1080,
        fps=25, bitrate='4500k', gop=50, youtube_api_key=api_key,
        pexels_api_key='', pixabay_api_key='', tts_engine='piper',
        tts_language='ru', tts_speaker='ru_RU-dmitri-medium', tts_speed=0.9,
        providers=[],
    )


def test_discovery_uses_three_periods_and_two_raw_api_orders(tmp_path, monkeypatch):
    calls = []

    def fake_get(path, params, api_key):
        calls.append((path, dict(params), api_key))
        if path == 'search':
            video_id = f"id-{len([x for x in calls if x[0] == 'search'])}"
            return {
                'pageInfo': {'totalResults': 1},
                'items': [{
                    'id': {'kind': 'youtube#video', 'videoId': video_id},
                    'snippet': {
                        'title': f'Test {video_id}',
                        'channelId': 'channel-1',
                        'channelTitle': 'Test channel',
                        'publishedAt': '2026-11-02T08:00:00Z',
                    },
                }],
            }
        vid = params['id']
        return {'items': [{
            'id': vid,
            'snippet': {
                'title': f'Test {vid}', 'channelId': 'channel-1',
                'channelTitle': 'Test channel',
                'publishedAt': '2026-11-02T08:00:00Z', 'categoryId': '28',
            },
            'statistics': {'viewCount': '12345', 'likeCount': '321'},
            'contentDetails': {'duration': 'PT5M20S'},
        }]}

    monkeypatch.setattr('video_farm.discovery._get', fake_get)
    fixed_now = dt.datetime(2026, 11, 2, 12, 0, tzinfo=dt.timezone.utc)
    report = discover_youtube(_settings(), tmp_path, now=fixed_now)

    assert len(report['windows']) == 3
    assert [w['window_days'] for w in report['windows']] == [1, 3, 7]
    assert report['quota_usage']['search_list_calls'] == 9
    assert report['quota_usage']['videos_list_calls'] == 9
    assert len([c for c in calls if c[0] == 'search']) == 9
    assert {c[1]['order'] for c in calls if c[0] == 'search'} == {'viewCount', 'date', 'relevance'}
    assert all(c[1]['regionCode'] == 'RU' for c in calls if c[0] == 'search')
    assert all(c[1]['relevanceLanguage'] == 'ru' for c in calls if c[0] == 'search')
    assert all(c[1]['type'] == 'video' for c in calls if c[0] == 'search')

    video = report['windows'][0]['sets']['viewCount']['videos'][0]
    assert video['view_count'] == 12345
    assert video['like_count'] == 321
    assert video['duration'] == 'PT5M20S'
    assert video['url'] == 'https://www.youtube.com/watch?v=id-1'
    assert 'viral_ratio' not in video
    assert 'views_per_hour' not in video
    assert 'trend_score' not in video

    saved = json.loads((tmp_path / 'discovery.json').read_text(encoding='utf-8'))
    assert saved['query'] == DEFAULT_QUERY
    assert (tmp_path / 'discovery.md').is_file()


def test_discovery_requires_api_key(tmp_path):
    with pytest.raises(RuntimeError, match='YOUTUBE_API_KEY'):
        discover_youtube(_settings(api_key=''), tmp_path)


def test_discovery_validates_query_and_limit(tmp_path):
    with pytest.raises(ValueError, match='пустым'):
        discover_youtube(_settings(), tmp_path, query='  ')
    with pytest.raises(ValueError, match='1 до 50'):
        discover_youtube(_settings(), tmp_path, max_results=51)


def test_discovery_requires_timezone_aware_now(tmp_path):
    with pytest.raises(ValueError, match='timezone-aware'):
        discover_youtube(_settings(), tmp_path, now=dt.datetime(2026, 11, 2))


def test_cleanup_deletes_only_expired_discovery_report(tmp_path):
    report = {
        "refresh_or_delete_by_utc": "2026-11-01T00:00:00Z",
        "source": "YouTube Data API v3",
    }
    (tmp_path / "discovery.json").write_text(json.dumps(report), encoding="utf-8")
    (tmp_path / "discovery.md").write_text("report", encoding="utf-8")
    unrelated = tmp_path / "keep.txt"
    unrelated.write_text("keep", encoding="utf-8")

    now = dt.datetime(2026, 11, 2, tzinfo=dt.timezone.utc)
    assert purge_expired_discovery_output(tmp_path, now=now) is True
    assert not (tmp_path / "discovery.json").exists()
    assert not (tmp_path / "discovery.md").exists()
    assert unrelated.read_text(encoding="utf-8") == "keep"


def test_cleanup_keeps_unexpired_discovery_report(tmp_path):
    report = {"refresh_or_delete_by_utc": "2026-12-01T00:00:00Z"}
    (tmp_path / "discovery.json").write_text(json.dumps(report), encoding="utf-8")
    (tmp_path / "discovery.md").write_text("report", encoding="utf-8")
    now = dt.datetime(2026, 11, 2, tzinfo=dt.timezone.utc)
    assert purge_expired_discovery_output(tmp_path, now=now) is False
    assert (tmp_path / "discovery.json").exists()
    assert (tmp_path / "discovery.md").exists()
